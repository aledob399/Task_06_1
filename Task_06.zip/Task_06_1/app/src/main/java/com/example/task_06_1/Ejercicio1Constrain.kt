package com.example.task_06_1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Ejercicio1Constrain : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ejercicio1_constrain)
    }
}